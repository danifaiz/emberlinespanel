<?php $__env->startSection('page_title'); ?>
    <?php echo e("Emberlines | Projects"); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_sub_title'); ?>
    <?php echo e("ADMIN PANEL"); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageStyles'); ?>
<style>
    #exampleModalLabel {
        font-family: 'Muli','Poppins';
        font-weight: bold;
    }
    .myshadow {
        box-shadow: 0px 0px 3px 1px #f2f2f2;
        margin-bottom:1em;
        border-radius:1%;
    }
    .mt-btm-1 {
       margin-bottom:1em;  
    }
    .move-right {
        text-align:right;
    }
    .btn-outline-danger {
        padding: 0.3rem 0.5rem !important;
        color: #fd397a !important;
        border-color: #fd397a !important;
    }
    
    .btn-outline-danger:hover {
        color:white !important;
        background-color:#fd397a !important;
    }
    .select2 {
        width:295px;
    }
    .wrap-text {
        word-wrap:break-word;
        width:70%;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>

<!-- end:: Header -->
<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-grid--stretch" style="margin-top:1%;">
	<div class="kt-container kt-body  kt-grid kt-grid--ver" id="kt_body">
		<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor">

			<!-- begin:: Content Head -->
			<div class="kt-subheader   kt-grid__item" id="kt_subheader">
				<div class="kt-subheader__main">
					<h3 class="kt-subheader__title">Dashboard</h3>
					<span class="kt-subheader__separator kt-subheader__separator--v"></span>
					<h3 class="kt-subheader__title">Project Stack</h3>
				</div>
				<div class="kt-subheader__toolbar">
                        <?php if(Session::has('message')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
                        <script>
                            setTimeout(()=>{
                                $(".alert").fadeOut();
                            },3000);
                         </script>
                        <?php endif; ?>
				</div>
			</div>
            <div class="kt-portlet__body">
                    
                    <div class="row">
                        <div class="col-md-12 myshadow">
                           <div class="kt-portlet kt-portlet--mobile">
                            <div class="kt-portlet__head kt-portlet__head--lg">
                                <div class="kt-portlet__head-label">
                                    <span class="kt-portlet__head-icon">
                                        <i class="kt-font-brand flaticon2-line-chart"></i>
                                    </span>
                                    <h3 class="kt-portlet__head-title">
                                        Emberlines Projects
                                    </h3>
                                </div>
                                <div class="kt-portlet__head-toolbar">
                                    <div class="kt-portlet__head-wrapper">
                                        <div class="kt-portlet__head-actions">
                                            <a href="/admin/project/add" class="btn btn-brand btn-elevate btn-icon-sm">
                                                <i class="la la-plus"></i>
                                                New Project
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="kt-portlet__body">

                                <!--begin: Datatable -->
                                <table class="table table-striped- table-bordered table-hover table-checkable" id="kt_table_1">
                                    <thead>
                                        <tr>
                                            <th>Project</th>
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Tags</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><img width="80" src="/storage/gallery/<?php echo e($project->banner_image); ?>" alt="<?php echo e($project->banner_image); ?>"></td>
                                                <td><?php echo e($project->title); ?></td>
                                                <td class="wrap-text"><?php echo e($project->description); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $project->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span style="margin:3px 0px;" class="kt-badge kt-badge--info kt-badge--inline kt-badge--pill kt-badge--rounded"><?php echo e($tag->name); ?></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td nowrap>
                                                    <a href="/admin/project/<?php echo e($project->id); ?>" class="btn btn-sm btn-clean btn-icon btn-icon-md"  data-skin="dark" data-toggle="kt-tooltip" data-placement="top" title="Edit">
                                                            <i class="la la-edit"></i>
                                                    </a>
                                                    <form action="<?php echo e(url('/admin/project/remove', ['id' => $project->id])); ?>" method="POST">
                                                        <?php echo method_field('delete'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit"  onclick="return confirm('Are you sure?')" class="btn btn-sm btn-clean btn-icon btn-icon-md"  data-skin="dark" data-toggle="kt-tooltip" data-placement="top" title="Delete">
                                                            <i class="la la-remove"></i>
                                                        </a>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                <!--end: Datatable -->
                            </div>
                        </div>
                            
                        </div>
                        
                        
                    </div>
                        
                    </div>

			<!-- end:: Content Head -->

			<!-- begin:: Content -->
	
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pageScripts"); ?>
    <script src="//cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.4.0/clipboard.min.js"></script>
    <script>
        var baseUrl = "<?php echo e(asset('/')); ?>";
    </script>
    <script src="<?php echo e(asset('app/bundle/ember.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\emberline\resources\views/ember/list_projects.blade.php ENDPATH**/ ?>